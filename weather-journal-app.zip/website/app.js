/* Global Variables */

// Create a new date instance dynamically with JS
let d = new Date();
let newDate = d.getMonth()+1 + '.'+ d.getDate()+'.'+ d.getFullYear();

//Checking that the date is printed correctly in the console
console.log(newDate)


const api = "b729cfdfeae72146d6852945e898141d" //API key from openweather

const btn = document.getElementById('generate') //Generate button

//Wrapping the whole functionality under one function 
const getData = async () => {
    const zipCode = document.getElementById('zip').value;
    const content = document.getElementById('feelings').value;
    const url = `https://api.openweathermap.org/data/2.5/weather?zip=${zipCode}&appid=${api}&units=metric`;
    if(zipCode === ""){
        alert('Please enter the zip code for the location');
    } else {
        try{
            
            // Fetching the forecast data from openweather.com
            const data = await fetch(url);
            const weatherData = await data.json()
            const temperature = weatherData.main.temp
            console.log(weatherData)
            console.log(temperature)

            // Sending the data in a POST request inside its body and storing it in the projectData object
            await fetch ('Request', {
                method:"POST",
                credentials:"same-origin",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    date: newDate,
                    temp: temperature,
                    content,
                }),
            });

            // Receiving data from the local server through GET route 
            const projject = await fetch ('/projectData');
            const dataa = await projject.json();

            console.log(dataa);
            
            //Updating the client side webpage with the temperature and the date
            document.getElementById('date').innerHTML = `Today's date is ${dataa.date}`
            document.getElementById('temp').innerHTML = `Today's temperature is ${dataa.temp}`
            document.getElementById('content').innerHTML = `You're feeling ${dataa.content}`
        }
        catch (error){
            console.log('ERROR: ', error)
        }
    }    
}
btn.addEventListener('click', getData)